console.log("Operações Aritiméticas");
//Numeros 
console.log(2+2);
console.log(10 + 8 * 2);
console.log((10 + 8) * 2);
//String ou texto

console.log("Ano "+2020);
console.log("2"+ 2);




