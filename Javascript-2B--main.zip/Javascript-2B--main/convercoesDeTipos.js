console.log("Conversão de Tipos");

console.log("ano"+2020);
console.log("2"+"2");

console.log(parseInt("2")+ parseInt("2"));
console.log("10"/ "2");
console.log("Gabriel" / "2");

console.log("7" / "2");

console.log(6.5);