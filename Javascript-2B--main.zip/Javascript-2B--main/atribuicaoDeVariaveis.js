console.log("Trabalhando com atribuuição de variáveis");

const idade = 26;
const primeironome = "Gabriel";
const sobrenome = "Pires";

const nomeCompleto = primeironome + sobrenome;

console.log(primeironome + " " + sobrenome);
console.log(primeironome, sobrenome);
console.log(`Meu nome é ${primeironome} ${sobrenome}`);
console.log(`Meu nome é ${nomeCompleto}`);

