console.log("Trabalhando com variáveis");
//JS é case sensitive

const idade = 26;
const nome = "Gabriel Pires";
let ano = 1997;

console.log ("Bom dia ",nome," sua idade é ",idade,"e o ano de nascimento é ",ano);
