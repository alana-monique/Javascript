console.log("Meu primeiro programa: trabalhando com variáveis");

const idade = 26;

const idadeSoma = idade + 2;

console.log("A soma da idade + 2 é ", idadeSoma); 

console.log("Sua idade é ", idade);
console.log("Sua idade + 2 é ", idade + 2);
console.log("Sua idade - 2 é ", idade - 2);
console.log("Sua idade / 2 é ", idade / 2);

