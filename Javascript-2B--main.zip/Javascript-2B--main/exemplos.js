console.log("Calculadora");

const numero1 = 15;
const numero2 = 20;

const soma = numero1 + numero2;
const subtracao = numero1 - numero2; 
const divisao = numero1 / numero2; 
const multiplicacao = numero1 * numero2; 

console.log(`A soma é ${soma}`);
console.log(`A subtração é ${subtracao}`);
console.log(`A divisão é ${divisao}`);
console.log(`A multiplicação é ${multiplicacao}`);

console.log(`A soma é ${soma},a subtração é ${subtracao}...`)








